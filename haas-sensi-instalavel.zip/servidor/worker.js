// HAAS SENSI - servidor de acesso (Cloudflare Worker + KV)
// Cada codigo vale para uma pessoa: liga em ate MAX_DEVICES aparelhos (padrao 2).
// O app fica criptografado no site (app.enc). Este servidor so entrega a chave para codigos validos.
//
// Configurar no painel do Cloudflare:
//   KV namespace ligado ao Worker com o nome de variavel:  LICENSES
//   ALLOWED_ORIGIN = https://SEUUSUARIO.github.io     (sem barra no final)
//   APP_KEY        = (Secret) conteudo do arquivo CHAVE-SECRETA.txt
//   ADMIN_KEY      = (Secret) uma senha longa so sua
//   MAX_DEVICES    = 2   (opcional)

const ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const J = (o, s, c) => new Response(JSON.stringify(o), {
  status: s || 200,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...c },
});
const norm = (c) => String(c || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
const fmt = (n) => n.slice(0, 4) + "-" + n.slice(4, 9) + "-" + n.slice(9);
function newCode() {
  const b = new Uint8Array(10);
  crypto.getRandomValues(b);
  let s = "HAAS";
  for (const x of b) s += ALPHA[x % 32];
  return s;
}
function eq(a, b) {
  a = String(a || ""); b = String(b || "");
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

async function activate(env, b, c) {
  const code = norm(b.code), dev = String(b.dev || "").slice(0, 80);
  if (!/^HAAS[A-Z2-9]{10}$/.test(code) || dev.length < 8) return J({ ok: false, error: "invalid" }, 200, c);
  const raw = await env.LICENSES.get(code);
  if (!raw) return J({ ok: false, error: "invalid" }, 200, c);
  const lic = JSON.parse(raw);
  if (lic.revoked) return J({ ok: false, error: "revoked" }, 200, c);
  const max = parseInt(env.MAX_DEVICES, 10) || 2;
  if (!lic.devices.includes(dev)) {
    if (lic.devices.length >= max) return J({ ok: false, error: "used" }, 200, c);
    lic.devices.push(dev);
    lic.first = lic.first || Date.now();
    await env.LICENSES.put(code, JSON.stringify(lic));
  }
  return J({ ok: true, key: env.APP_KEY }, 200, c);
}

async function admin(env, path, b, c) {
  if (path === "/admin/new") {
    const n = Math.max(1, Math.min(50, parseInt(b.n, 10) || 1));
    const label = String(b.label || "").slice(0, 40), out = [];
    for (let i = 0; i < n; i++) {
      const code = newCode();
      await env.LICENSES.put(code, JSON.stringify({ label, created: Date.now(), devices: [], revoked: false }));
      out.push(fmt(code));
    }
    return J({ ok: true, codes: out }, 200, c);
  }
  if (path === "/admin/list") {
    const l = await env.LICENSES.list({ limit: 200 }), out = [];
    for (const k of l.keys) {
      const v = await env.LICENSES.get(k.name);
      if (!v) continue;
      const d = JSON.parse(v);
      out.push({ code: fmt(k.name), label: d.label, devices: d.devices.length, revoked: !!d.revoked, created: d.created });
    }
    return J({ ok: true, list: out, max: parseInt(env.MAX_DEVICES, 10) || 2 }, 200, c);
  }
  const code = norm(b.code);
  const raw = code && (await env.LICENSES.get(code));
  if (!raw) return J({ ok: false, error: "notfound" }, 404, c);
  const d = JSON.parse(raw);
  if (path === "/admin/reset") d.devices = [];
  else if (path === "/admin/revoke") d.revoked = b.revoked !== false;
  else return J({ ok: false, error: "route" }, 404, c);
  await env.LICENSES.put(code, JSON.stringify(d));
  return J({ ok: true }, 200, c);
}

export default {
  async fetch(req, env) {
    if (!env.ALLOWED_ORIGIN || !env.LICENSES || !env.APP_KEY || !env.ADMIN_KEY)
      return new Response("Configure as variaveis do Worker", { status: 500 });
    const c = {
      "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN, Vary: "Origin",
      "Access-Control-Allow-Methods": "POST,OPTIONS", "Access-Control-Allow-Headers": "content-type,x-admin-key",
    };
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: { ...c, "Access-Control-Max-Age": "86400" } });
    if (req.method !== "POST") return J({ ok: false, error: "method" }, 405, c);
    if ((req.headers.get("Origin") || "") !== env.ALLOWED_ORIGIN) return J({ ok: false, error: "origin" }, 403, c);
    const path = new URL(req.url).pathname;
    let body = {};
    try { body = (await req.json()) || {}; } catch (e) {}
    if (path === "/activate") return activate(env, body, c);
    if (path.startsWith("/admin/")) {
      if (!eq(req.headers.get("x-admin-key"), env.ADMIN_KEY)) return J({ ok: false, error: "auth" }, 401, c);
      return admin(env, path, body, c);
    }
    return J({ ok: false, error: "route" }, 404, c);
  },
};
